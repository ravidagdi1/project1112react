const router=require('express').Router()
const regc=require('../controllers/regcontroler')
const productc=require('../controllers/productscontroller')


router.post('/reg',regc.register)
router.post('/login',regc.login)
router.post('/productadd',productc.productadd)
router.get('/allproducts',productc.allproducts)
router.get('/singleproduct/:id',productc.singleproduct)
router.put('/productupdate/:id',productc.update)
router.get('/productinstock',productc.productsinstock)
router.post('/productbyid',productc.productsbyid)




module.exports=router